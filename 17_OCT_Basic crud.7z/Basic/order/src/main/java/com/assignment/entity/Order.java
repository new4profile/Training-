package com.assignment.entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="order_detls")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int id;
	@Column(name="order_desc")
	String orderDesc;
	@Column(name="oder_amnt")
	double orderAmnt;
	@Column(name="oder_status")
	String orderStatus;
	@Column(name="order_date")
	LocalDate orderDate;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getOrderDesc() {
		return orderDesc;
	}
	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}
	public double getOrderAmnt() {
		return orderAmnt;
	}
	public void setOrderAmnt(double orderAmnt) {
		this.orderAmnt = orderAmnt;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int id, String orderDesc, double orderAmnt, String orderStatus) {
		super();
		this.id = id;
		this.orderDesc = orderDesc;
		this.orderAmnt = orderAmnt;
		this.orderStatus = orderStatus;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", orderDesc=" + orderDesc + ", orderAmnt=" + orderAmnt + ", orderStatus="
				+ orderStatus + ", orderDate=" + orderDate + "]";
	}
	

	void generateOrderDate() {
		this.orderDate=LocalDate.now();
	}
	
	
	
}
