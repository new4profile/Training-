package com.assignment.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.entity.Order;
import com.assignment.repository.OrderRepo;
@Service
public class OrderServiceImpl implements OrderService{
	@Autowired
	OrderRepo orderRepo;
	
	
	@Override
	public List<Order> findAll() {
		return orderRepo.findAll();
	}

	@Override
	public void save(Order order) {
		orderRepo.save(order);
	}

	@Override
	public Optional<Order> findById(int id) {
		return orderRepo.findById(id);
	}

	@Override
	public void deleteById(int id) {
		orderRepo.deleteById(id);
		
	}

}
