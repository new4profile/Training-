package com.assignment.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.entity.Payment;
import com.assignment.repo.PaymentRepo;
@Service
public class PaymentServiceImpl implements PaymentService{
	
	@Autowired
	PaymentRepo payRepo;
	@Override
	public List<Payment> findAll() {
		return payRepo.findAll();
	}

	@Override
	public void save(Payment payment) {
		payRepo.save(payment);
	}

	@Override
	public Optional<Payment> findById(int id) {
		return payRepo.findById(id);
	}

	@Override
	public void deleteById(int id) {
		payRepo.deleteById(id);
	}

}
