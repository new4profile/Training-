package com.assignment.service;

import java.util.List;
import java.util.Optional;

import com.assignment.entity.Payment;

public interface PaymentService {
	
	List<Payment> findAll();
	void save(Payment payment);
	Optional<Payment> findById(int id);
	void deleteById(int id);

}
