package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.entity.Payment;
import com.assignment.service.PaymentService;

@RestController
public class PaymentContoller {
	
	@Autowired
	PaymentService payServ;
	
	
	@PostMapping("/payment")
	public void save(@RequestBody Payment payment) {
		payServ.save(payment);		
	}
	@GetMapping("/payment")
	public List<Payment> findAll() {
		return payServ.findAll();
	}
	@GetMapping("/payment/{id}")
	public Payment findById(@PathVariable int id) {
		return payServ.findById(id).get();
	}
	@DeleteMapping("/payment/{id}")
	public void deleteById(@PathVariable int id) {
		payServ.deleteById(id);
	}

}
