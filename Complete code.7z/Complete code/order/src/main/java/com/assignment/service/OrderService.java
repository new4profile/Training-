package com.assignment.service;

import java.util.List;
import java.util.Optional;

import com.assignment.entity.Order;

public interface OrderService {
	List<Order> findAll();
	void save(Order order);
	Optional<Order> findById(int id);
	void deleteById(int id);
}
