package com.assignment.service;

import java.time.LocalDate;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.assignment.dto.PaymentDto;
import com.assignment.entity.Order;
import com.assignment.repository.OrderRepo;
@Service
public class OrderServiceImpl implements OrderService{
	@Autowired
	OrderRepo orderRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public List<Order> findAll() {
		return orderRepo.findAll();
	}

	@Override
	public void save(Order order) {
		order.setOrderDate(LocalDate.now());
		
		String paymentUrl="http://localhost:8080/payment";
		
		Order save = orderRepo.save(order);
		int orderId=order.getId();
		
		PaymentDto pay=new PaymentDto(orderId, order.getOrderAmnt()); //pass order id from order table into the payment table
		
//		RestTemplate restTemplate=new RestTemplate();
		ResponseEntity<PaymentDto> res= restTemplate.postForEntity(paymentUrl, pay, PaymentDto.class);
		if(res.getStatusCode()==HttpStatus.OK) {
			order.setOrderStatus("paid");
			orderRepo.save(order);
		}
	}

	@Override
	public Optional<Order> findById(int id) {
		return orderRepo.findById(id);
	}

	@Override
	public void deleteById(int id) {
		orderRepo.deleteById(id);
		
	}

}
