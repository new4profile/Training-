package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class EntityClass {
	@Id
	int id;
	

}
