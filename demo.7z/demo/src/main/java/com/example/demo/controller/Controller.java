package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.Servic;

@RestController
public class Controller {
	
	@Autowired
	Servic serv;
	
	@GetMapping
	void save() {}
	void getAll() {}
	void getbyId(int id) {}
	void deleteById(int id) {}
	
}
	
	